<?php
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASS", "111111");
	define("DB_NAME", "us_db");
?>