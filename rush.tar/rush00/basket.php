<?php
require("define.php");
$con = mysqli_connect(DB_HOST, DB_USER, DB_PASS);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());}

mysqli_select_db($con, DB_NAME) or die("Cannot select DB");
 
 
/**
 * для удобства, а не для понтов,
 * создадим функцию-обертку получения результатов из базы
 */
 
function DbQuery($query) {
  $result = mysqli_query($con, $query) or die("Смотри куда прёшь: " . mysqli_error());
  $arr = array();
  while ($row = mysqli_fetch_assoc($result)) {
    $arr[] = $row;
  }
  return $arr;
}
 
 
/**
 * и еще одну для обновления данных
 * INSERT, DELETE или UPDATE
 * возвращать то нам тут ничего не надо
 */
 
function DbSet($query) {
  mysqli_query($con, $query) or die("Нее, не прокатит: " . mysqli_error());
}
 
 
/**
 * после любых изменений в корзине,
 * надо типа делать редирект на просмотр списка товаров
 * в актуальном виде внутри корзины,
 * чтоб не повадно было коцать добавление товара
 * такой маленький антидидос :)
 */
 
function resetStatus() {
  header("Location: /basket.php");
  die();
}
 
 
/**
 * плюс один товар в позиции
 * проще некуда, добавляет новую запись в таблицу
 */
 
function addToBasket($hash, $id) {
  DbSet("INSERT INTO basket (id,hash,product_id) VALUES (NULL,'$hash',$id)");
}
 
 
/**
 * пытаемся удалить ТОЛЬКО ОДНУ! запись из таблицы
 * если таковая существует
 */
 
function minusInnerBasket($hash, $id) {
  DbSet("DELETE FROM basket WHERE hash = '$hash' AND product_id = $id LIMIT 1");
}
 
 
/**
 * удаляем всю позицию из корзины
 * сколько бы там товаров ни было в количестве
 * где хеш - это хеш пользака,
 * и айди - это айди товара
 */
 
function deleteFromBasket($hash, $id) {
  DbSet("DELETE FROM basket WHERE hash = '$hash' AND product_id = $id");
}
 
 
/**
 * теперь сам "контроллер" описанных выше действий с корзиной
 * собственно это и есть зачаток нормального контроллера
 * но тут он совсем прост
 * и нам не суть разбираться в этих тонкостях прямо сейчас
 */
 
function controller($hash) {
  if (isset($_GET['add']) and (int) $_GET['add'] > 0) {
    // плюс один товар в позиции
    addToBasket($hash, (int) $_GET['add']);
    resetStatus();
  } else if (isset($_GET['minus']) and (int) $_GET['minus'] > 0) {
    // минус один товар в позиции
    minusInnerBasket($hash, (int) $_GET['minus']);
    resetStatus();
  } else if (isset($_GET['del']) and (int) $_GET['del'] > 0) {
    // полное удаление позиции товара
    deleteFromBasket($hash, (int) $_GET['del']);
    resetStatus();
  }
}
 
 
/**
 * теперь собственно запустим все это чудо в работу
 */
 
if (isset($_COOKIE['basket']) and ((string) $_COOKIE['basket'])) {
  // если кука корзины была
  $basket_hash = (string) $_COOKIE['basket'];
} else {
  // ну или если куки корзины не было
  $basket_hash = md5("не забудьте посолить" . microtime());
}
 
// обновляем куку в любом случае
setcookie("basket", $basket_hash, time() + 26400);
 
 
/**
 * а вот тут дергаем наш "контроллер"
 * передав ему хеш корзины текущего пользака
 */
 
controller($basket_hash);
 
 
/**
 * тут или контроллер отработает
 * и сделает редирект на /basket.php без параметров
 * или то, что идет ниже, уже есть /basket.php без параметров :)
 * получам список товаров В КОРЗИНЕ и их кол-во ОДНИМ ЗАПРОСОМ
 * сортируем сразу по кол-ву товаров в позиции
 * первыми будут идти те позиции,
 * в которых большее кол-во товаров
 */
 
$productsInBasket = DbQuery("
   SELECT b.product_id, COUNT(b.product_id) cnt, p.name, p.price
     FROM basket b
     JOIN products p ON p.id = b.product_id
     WHERE b.hash = '$basket_hash'
     GROUP BY b.product_id
     ORDER BY cnt DESC
");
 
 
/**
 * получам просто список товаров для теста
 * ну штук десять например
 */
 
$products = DbQuery("
   SELECT * FROM products ORDER BY price DESC LIMIT 10;
");
 
 
/**
 * и тут наверное уже 70% подумало "а где же эти <TR><TD>?"
 * спокойно, сейчас они появятся :)
 * все данные получены, теперь их можно выводить
 * подключаем шаблон вывода
 */
 
require_once "basket_template.html";