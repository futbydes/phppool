<?php include("includes/header.php"); ?>
<div class="container mlogin">
	<div id="login">
		<h1>Contact us</h1>
		La da da da da, la da da da da <br />
		Da da da <br />
		We are searchlights, we can see in the dark <br />
		We are rockets, pointed up at the stars <br />
We are billions of beautiful hearts <br />
And you sold us down the river too far <br />
What about us? <br />
What about all the times you said you had the answers? <br />
What about us?<br />
What about all the broken happy ever afters?<br />
What about us?<br />
What about all the plans that ended in disaster?<br />
What about love? What about trust?<br />
What about us?<br />
We are problems that want to be solved<br />
We are children that need to be loved<br />
We were willin', we came when you called<br />
But, man, you fooled us, enough is enough, oh<br />
What about us?<br />
What about all the times you said you had the answers?<br />
What about us?<br />
What about all the broken happy ever afters?<br />
Oh, what about us?<br />
What about all the plans that ended in disaster?<br />
Oh, what about love? What about trust?<br />
What about us?<br />
Oh, what about us?<br />
What about all the plans that ended in disaster?<br />
What about love? What about trust?<br />
What about us?<br />
Sticks and stones, they may break these bones<br />
But then I'll be ready, are you ready?<br />
It's the start of us, waking up, come on<br />
Are you ready? I'll be ready<br />
I don't want control, I want to let go<br />
Are you ready? I'll be ready<br />
'Cause now it's time to let them know<br />
We are ready, what about us?<br />
What about us?<br />
What about all the times you said you had the answers?<br />
So what about us?<br />
What about all the broken happy ever afters?<br />
Oh, what about us?<br />
What about all the plans that ended in disaster?<br />
Oh, what about love? What about trust?<br />
What about us?<br />
What about us?<br />
What about us?<br />
What about us?<br />
What about us?<br />
What about us?<br />
What about us?<br />
 	</div>
 </div>
 <?php include("includes/footer.php"); ?>